## Copyright notice
## Copyright 2025 Markus Haas
##
## Statement of copying permission
## This file is part of epror.
## epror is an R package for analyzing experimental data obtained with express 
## profiling from a Beckman Coulter, Inc or Sciex CEQ8800 capillary 
## electrophoresis device.
## 
##     epror is free software: you can redistribute it and/or modify
##     it under the terms of the GNU General Public License as published by
##     the Free Software Foundation, either version 3 of the License, or
##     (at your option) any later version.
## 
##     epror is distributed in the hope that it will be useful,
##     but WITHOUT ANY WARRANTY; without even the implied warranty of
##     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##     GNU General Public License for more details.
## 
##     You should have received a copy of the GNU General Public License
##     along with epror. If not, see <http://www.gnu.org/licenses/>.

#' This function graphically displays the fragment list of all
#' AB Sciex CEQ8800 instrument fragment files in the current directory
#'
#' This function displays the fragment list of all
#' AB Sciex CEQ8800 instrument fragment files in the current directory
#' which match the file extension pattern given with the parameter
#' fragfileext. 
#' All files which match the pattern given of the parameter fragfileext in the 
#' current working directory  will be parsed. This function is a wrapper
#' for the function epr.plotfrag() and allows you to
#' cycles through all files in the working directory which match the
#' file extension pattern given with the parameter fragfileext.
#' @param fragfileext The extension of the files which should be read by
#' the function. Defaults to "ceqfrag".
#' @param xlim Vector containing the limits of the x-axis. Defaults to c(NULL,NULL).
#' @param ylim Vector containing the limits of the y-axis. Defaults to c(NULL,NULL).
#' @param transcripts Name of the file wiht a table of all fragments 
#' which should be detected. This file will be read by the function 
#' epr.readtranscripts(). Defaults to "transcripts.txt".
#' @export

epr.plotallfrag = function(fragfileext = "ceqfrag",  transcripts = "transcripts.txt", 
			   xlim = c(NULL,NULL), ylim = c(NULL,NULL)){

  filelist = Sys.glob(paste("*.", fragfileext, sep = ""))

  for (file in filelist){
    epr.plotfrag(file, transcripts = transcripts, xlim = xlim, ylim = ylim)
    invisible(readline(prompt="Press [enter] to continue"))
  }
  dev.off()
}

