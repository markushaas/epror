## Copyright notice
## Copyright 2025 Markus Haas
##
## Statement of copying permission
## This file is part of epror.
## epror is an R package for analyzing experimental data obtained with express 
## profiling from a Beckman Coulter, Inc or Sciex CEQ8800 capillary 
## electrophoresis device.
## 
##     epror is free software: you can redistribute it and/or modify
##     it under the terms of the GNU General Public License as published by
##     the Free Software Foundation, either version 3 of the License, or
##     (at your option) any later version.
## 
##     epror is distributed in the hope that it will be useful,
##     but WITHOUT ANY WARRANTY; without even the implied warranty of
##     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##     GNU General Public License for more details.
## 
##     You should have received a copy of the GNU General Public License
##     along with epror. If not, see <http://www.gnu.org/licenses/>.

#' This function calculates transcript amounts
#'
#' This function calculates the amount of a given set of transcripts
#' based on so called standard values (see epr.makestd for details).
#' @param mrna Numeric. The amount of RNA in ng which was added to the
#' RT reaction for the express profiling method.
#' @param file The name of a fragment file from the AB Sciex CEQ800
#' software.
#' @param wtf Logical. When set to TRUE the detected fragments of
#' the input file will be written to a file with the extension "resultfileext"
#' (see below). Defaults to FALSE.
#' @param resultfileext If wtf is set to TRUE, resultfileext will be chosen
#' as extension for the files containing all detected fragments of each
#' input file. Defaults to "frag".
#' @param standardvaluefile Name of the file with the standard values
#' from the function epr.makestd() from the epror package.
#' @param transcripts Name of the file with a table of all fragments 
#' which should be detected. This file will be read by the function 
#' epr.readtranscripts(). Defaults to "transcripts.txt".
#' @export
#' @import utils tools

epr.calcamount = function(mrna, file, wtf = FALSE, resultfileext = "frag", 
			   standardvaluefile = "standardvalues", transcripts = "transcripts.txt", outputdir = "./"){

  transcriptid = NULL
  size = NULL
  dye = NULL
  area = NULL
  fragid = NULL

  ## Read list of fragments to search for
  t = epr.readtranscripts(transcripts)
  t0 = subset(t, transcriptid == 0)
  t1 = subset(t, transcriptid > 0)

  ## Read analysisparameter
  settings = epr.readsettings()

  ## Read standardvalues
  standardvalues = read.table(standardvaluefile, sep = "\t", header = TRUE)

  ## Initialize dataframe for output
  x2 = data.frame(matrix(vector(),ncol=11))
  colnames(x2) = c("dye","migtime","size", "height", "area", "width", "mob", 
		   "fragid","npa","amount","amountlimit")

  ## Read ceq fragment file
  x1 = epr.readfragfile(file)[,c(3,4,6,7,8,9,10)]
  secondheighest = sort(x1$height, TRUE)[2]

  ## Search for reference transcript
  s1 = subset(x1, size > t0$runlength - settings[["range"]] 
	      & size < t0$runlength + settings[["range"]] 
	      & dye == settings[["universalprimerdye"]])

  if (nrow(s1) > 0){
    s1$fragid = 0
    area0 = subset(s1, area == max(s1$area))[1,]$area
    s1$npa = s1$area / area0
    x2[nrow(x2) + 1,] = c(subset(s1, area == max(s1$area))[1,],NA,NA)
  } else {
    x2[nrow(x2) + 1,] = c(rep(NA,7),0,NA,NA,NA)
  }

  ## Search for transcripts
  for (i in 1:nrow(t1)) {
    fragment = t1[i,1]
    if (nrow(subset(standardvalues, fragid == fragment)) > 0){
      runlength = t1[i,2]
      slope = subset(standardvalues, fragid == fragment)$avslope
      yicpt = subset(standardvalues, fragid == fragment)$yicptav
      s1 = subset(x1, size > runlength - settings[["range"]] 
		  & size < runlength + settings[["range"]] 
		  & dye == settings[["universalprimerdye"]])

      ## Calculate normalized peak area, amount and amountlimit
      if (nrow(s1) > 0){
	s1$fragid = fragment
	s1$npa = s1$area / area0
	s1$amount = (10**(((log(s1$npa)/log(10)) - yicpt)/slope))/mrna
	npalimit = secondheighest * settings[["peakheightthreshold"]] * settings[["heightpeaklowestratio"]] / area0
	s1$amountlimit = (10**(((log(npalimit)/log(10)) - yicpt)/slope))/mrna
	x2[nrow(x2) + 1,] = subset(s1, area == max(s1$area))[1,]
      } else {
	npalimit = secondheighest * settings[["peakheightthreshold"]] * settings[["heightpeaklowestratio"]] / area0
	amountlimit = (10**(((log(npalimit)/log(10)) - yicpt)/slope))/mrna
	x2[nrow(x2) + 1,] = c(rep(NA,7),fragment,NA,NA,amountlimit)
      }
    }else{
      x2[nrow(x2) + 1,] = c(rep(NA,7),fragment,NA,NA,NA)
    }
  }

  ## write to file
  if (wtf){
    write.table(round(x2[,c(8,2,3,4,5,9,10,11)], digits = 5), 
		file = paste(outputdir, file_path_sans_ext(file), ".", resultfileext, sep = ""), 
		append = FALSE, quote = FALSE, sep = "\t", eol = "\n", 
		na = "NA", dec = ".", row.names = FALSE)
  }
  x2$ceqid = file_path_sans_ext(file)

  return(x2[,c(12,8,2,3,4,5,9,10,11)])
}

