## Copyright notice
## Copyright 2025 Markus Haas
##
## Statement of copying permission
## This file is part of epror.
## epror is an R package for analyzing experimental data obtained with express 
## profiling from a Beckman Coulter, Inc or Sciex CEQ8800 capillary 
## electrophoresis device.
## 
##     epror is free software: you can redistribute it and/or modify
##     it under the terms of the GNU General Public License as published by
##     the Free Software Foundation, either version 3 of the License, or
##     (at your option) any later version.
## 
##     epror is distributed in the hope that it will be useful,
##     but WITHOUT ANY WARRANTY; without even the implied warranty of
##     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##     GNU General Public License for more details.
## 
##     You should have received a copy of the GNU General Public License
##     along with epror. If not, see <http://www.gnu.org/licenses/>.

#' This function reads a file with the raw data of an electropherogram of AB Sciex CEQ800 instrument
#'
#' This function reads a table from raw data of an electropherogram of an 
#' AB Sciex CEQ800 instrument. The file must be exported in the csv format
#' from the database module of the CEQ800 software. This function returns a
#' data frame with the run data.
#' @param file File name with raw data from an AB Sciex CEQ800 instrument.
#' @import utils
#' @export
#' @examples 
#' file <- system.file("extdata", "FA034580.ceqraw", package="epror")
#' epr.readrawdata(file)

epr.readrawdata = function(file) {
  lines = readLines(file)

  table.entry = lines == "\tRaw Data Output\tSeparation"

  empty.lines = which(lines == "")
  empty.lines = c(empty.lines, length(lines) + 1L)

  if(length(lines)){
    starttime = as.numeric(strsplit(lines[grep("Start", lines)],
				    "\t",perl = T)[[1]][3])
    stoptime = as.numeric(strsplit(lines[grep("Start", lines)],
				   "\t",perl = T)[[1]][5])
  }

  table.start = which(table.entry) + 6L
  table.end = empty.lines[which(empty.lines > table.start)[1]] - 1L

  if(length(table.start) & length(table.end)){
    x = read.table(textConnection(lines[seq(from = table.start, to = table.end)]), 
		    sep = "\t", colClasses = c("integer", "character", 
					       rep("numeric", 12)))

    names(x) = c("index", "cap", "D4", "D3", "D2", "D1", "current", "voltage", 
		  "rawcurr", "totcurr", "injcurr", "injvolt", "injtotcurr", 
		  "rtncurr")

    x$time = (((x$index - 1)/(nrow(x) - 1)) * (stoptime - starttime)) - 1

    return(x)
  }
}

