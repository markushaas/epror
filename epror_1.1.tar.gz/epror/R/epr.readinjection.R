## Copyright notice
## Copyright 2025 Markus Haas
##
## Statement of copying permission
## This file is part of epror.
## epror is an R package for analyzing experimental data obtained with express 
## profiling from a Beckman Coulter, Inc or Sciex CEQ8800 capillary 
## electrophoresis device.
## 
##     epror is free software: you can redistribute it and/or modify
##     it under the terms of the GNU General Public License as published by
##     the Free Software Foundation, either version 3 of the License, or
##     (at your option) any later version.
## 
##     epror is distributed in the hope that it will be useful,
##     but WITHOUT ANY WARRANTY; without even the implied warranty of
##     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##     GNU General Public License for more details.
## 
##     You should have received a copy of the GNU General Public License
##     along with epror. If not, see <http://www.gnu.org/licenses/>.

#' This function reads the injection part of a file with the raw data of 
#' an electropherogram of AB Sciex CEQ800 instrument
#'
#' This function reads a table with the injection data from raw data of an electropherogram of an 
#' AB Sciex CEQ800 instrument. The file must be exported in the csv format
#' from the database modul of the CEQ800 software. This function returns a
#' data frame with the injection data.
#' @param file File name with raw data from an AB Sciex CEQ800 instrument.
#' @import utils
#' @export
#' @examples 
#' file <- system.file("extdata", "FA034580.ceqraw", package="epror")
#' epr.readinjection(file)

epr.readinjection = function(file) {
  lines = readLines(file)

  if(length(lines)){
    table.entry.1 = lines == "\tRaw Data Output\tInjection"
    table.entry.2 = lines == "\tRaw Data Output\tSeparation"
    table.start = which(table.entry.1) + 3L
    table.stop = which(table.entry.2) - 2L


    x = read.table(textConnection(
				  lines[seq(from = table.start, 
					    to = table.stop)]), 
		   sep = "\t", colClasses = c("integer", "character", 
					      rep("numeric", 12)))

    names(x) = c("index", "cap", "D4", "D3", "D2", "D1", "current", "voltage", 
		  "rawcurr", "totcurr", "injcurr", "injvolt", "injtotcurr", 
		  "rtncurr")

    return(x)
  }
}

