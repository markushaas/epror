## Copyright notice
## Copyright 2025 Markus Haas
##
## Statement of copying permission
## This file is part of epror.
## epror is an R package for analyzing experimental data obtained with express 
## profiling from a Beckman Coulter, Inc or Sciex CEQ8800 capillary 
## electrophoresis device.
## 
##     epror is free software: you can redistribute it and/or modify
##     it under the terms of the GNU General Public License as published by
##     the Free Software Foundation, either version 3 of the License, or
##     (at your option) any later version.
## 
##     epror is distributed in the hope that it will be useful,
##     but WITHOUT ANY WARRANTY; without even the implied warranty of
##     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##     GNU General Public License for more details.
## 
##     You should have received a copy of the GNU General Public License
##     along with epror. If not, see <http://www.gnu.org/licenses/>.

#' This function plots current and voltage from electropherograms of
#' AB Sciex CEQ8800 instrument files
#'
#' This function plots current and voltage from electropherogram from
#' AB Sciex CEQ8800 instrument files.
#' @param file The name of the AB Sciex CEQ8800 instrument file with the
#' raw data of the electropheorgram. The file must be exported from the
#' database module of the instrument software in the txt format.
#' @param xlim Vector containing the limits of the x-axis. Defaults to c(NULL,NULL).
#' @importFrom graphics par plot title grid lines points legend mtext axis
#' @export

epr.plotcv = function(file, xlim = c(NULL,NULL)){

  x = epr.readrawdata(file)
  cap = x[1,]$cap

  ymax = max(max(x$voltage), max(x$current)) * 1.1
  xmax = max(x$time)

  par(mar = c(5, 5, 3, 5))
  
  plot(x$time, x$current, 
       type ="l",
       xlim = c(ifelse(!is.null(xlim[1]), xlim[1], 0), ifelse(!is.null(xlim[2]), xlim[2], xmax)),
       ylim = c(0, ymax),
       ylab = "",
       main = paste(file, cap, sep = ", Cap: "), 
       cex.main = 1,
       lwd = 2,
       xlab = "Migration Time in min",
       col = "red")
  
  mtext(expression(paste("Current in ", mu, "A")), side = 2, line = 3, col = "red")

  grid(nx = NULL, ny = NULL, col = "lightgray", lty = "dotted", lwd = 1.5)
  par(new = TRUE)
  
  plot(x$time, x$voltage, 
       type = "l", 
       xlim = c(ifelse(!is.null(xlim[1]), xlim[1], 0), ifelse(!is.null(xlim[2]), xlim[2], xmax)),
       ylim = c(0, ymax),
       xaxt = "n", yaxt = "n",
       ylab = "", xlab = "", 
       lwd = 2,
       col = "blue")

  axis(side = 4)
  
  mtext("Voltage in kV", side = 4, line = 3, col = "blue")
  legend("topright", legend = c("Current", "Voltage"), 
         bg = "white", col = c("red", "blue"), lty = 1, lwd = 2, ncol = 3)

}

