## Copyright notice
## Copyright 2025 Markus Haas
##
## Statement of copying permission
## This file is part of epror.
## epror is an R package for analyzing experimental data obtained with express 
## profiling from a Beckman Coulter, Inc or Sciex CEQ8800 capillary 
## electrophoresis device.
## 
##     epror is free software: you can redistribute it and/or modify
##     it under the terms of the GNU General Public License as published by
##     the Free Software Foundation, either version 3 of the License, or
##     (at your option) any later version.
## 
##     epror is distributed in the hope that it will be useful,
##     but WITHOUT ANY WARRANTY; without even the implied warranty of
##     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##     GNU General Public License for more details.
## 
##     You should have received a copy of the GNU General Public License
##     along with epror. If not, see <http://www.gnu.org/licenses/>.

#' This function calculates the standard curves for the express
#' profiling method
#'
#' This function calculates the standard curves for the express
#' profiling method to quantify transcripts. The function needs 
#' a file with a list of all fragments run data from an AB Sciex
#' CEQ8800 instrument with the amount of RNA in a second column
#' which was used for each run. Additionally you need a table 
#' with all transcripts which should be quantified. See epr.readtranscripts()
#' for details. The function returns a list. The first item called 
#' standardvalues is a data frame with the standardvalues which are
#' necessary to calculate the transcript amounts of sample data.
#' The second item called data points contains a data frame with all 
#' values which were used to calculate the standard curves. The third
#' item contains a data frame called alldata which contains all fragments
#' which could be detected by the function.
#' @param file Name of the file which contains a <TAB> separated table
#' with the file names of the fragment files from the AB Sciex CEQ8800
#' software in the first column and the RNA amount which was used for 
#' samples in the second column. Defaults to "amount.txt".
#' @param wtf Logical. When set to TRUE the standardvalues will be written
#' in a file named "standardvalues". Additionally the detected fragments of
#' each input file will be written to a file with the extension "resultfileext"
#' (see below). Defaults to FALSE.
#' @param transcripts Name of the file with a table of all fragments 
#' which should be detected. This file will be read by the function 
#' epr.readtranscripts(). Defaults to "transcripts.txt".
#' @param resultfileext If wtf is set to TRUE, resultfileext will be choosen
#' as extension for the files containing all detected fragments of each
#' input file. Defaults to "frag".
#' @export
#' @import utils
#' @importFrom stats coef lm na.omit

epr.makestd = function(file = "amount.txt", wtf = FALSE, transcripts = "transcripts.txt",
			     resultfileext = "frag", outputdir = "./"){

  size = NULL
  dye = NULL
  area = NULL

  ## Read table of transcripts to detect
  transcripts = epr.readtranscripts(transcripts)

  ## Read analysisparameter
  settings = epr.readsettings()

  ## Read file with filenames and rna amount
  lines = readLines(file)

  if(length(lines)){
    hitrows = grep("\t[0-9]+", lines)

    filenames = read.table(textConnection(lines[seq(from = min(hitrows), 
					    to = max(hitrows))]),
		    sep = "\t", colClasses = c("character","numeric"))
    colnames(filenames) = c("inputfilename","mrna")

  }

  ## Data frame to collect all detected fragments from each file
  x0 = data.frame(matrix(vector(),ncol=14))
  colnames(x0) = c("std","peak","dye","migtime","stdsize","size", "height", 
		    "area", "width", "mob", "eff", "res","fragid","amount")

  ## Read all CEQ8800 fragment list files 
  for (f in 1:nrow(filenames)) {
    x2 = data.frame(matrix(vector(),ncol=14))
    colnames(x2) = c("std","peak","dye","migtime","stdsize","size", "height", 
		      "area", "width", "mob", "eff", "res","fragid","amount")

    amount = filenames[f,2]
    x1 = epr.readfragfile(filenames[f,1])

    for (i in 1:nrow(transcripts)) {
      fragid = transcripts[i,1]
      runlength = transcripts[i,2]
      s1 = subset(x1, size > runlength - settings[["range"]] 
		  & size < runlength + settings[["range"]] 
		  & dye == settings[["universalprimerdye"]])
      if (nrow(s1) > 0){
	s1$fragid = fragid
	s1$amount = amount
	x2[nrow(x2) + 1,] = subset(s1, area == max(s1$area))[1,]
      }else{
	x2[nrow(x2) + 1,] = c(rep(NA, 12), fragid, amount)
      }
    }
    x2$npa = x2$area/x2[x2$fragid == 0, 8]
    x2$file = filenames[f,1]
    x0 = rbind(x0,x2)

    ## write detected transripts of each run to file
    if(wtf){
      write.table(round(x2[,c(13,4,6,7,8,15)], digits = 5), 
		  file = paste(outputdir, tools::file_path_sans_ext(filenames[f,1]), ".", resultfileext, sep = ""), 
		  append = FALSE, quote = FALSE, sep = "\t",
		  eol = "\n", na = "NA", dec = ".", row.names = FALSE)
    }
  }

  x4 = x0[,c(16,13,4,6,7,8,15)]
  x0 = na.omit(x0[,c(13,14,15)])
  sv = data.frame(matrix(vector(),ncol=4))
  colnames(sv) = c("fragid","slope","yicpt","rsquared")

  ## Calculate linear regression for each transript
  for (i in 1:nrow(transcripts)) {
    frag = transcripts[i,1]
    if (frag > 0){
      x3 = subset(x0, fragid == frag)
      if (nrow(x3) > 1){
	x3$lognpa = log(x3$npa)/log(10)
	x3$logamount = log(x3$amount)/log(10)
	linreg = lm(x3$lognpa ~ x3$logamount)
	sv[nrow(sv) + 1,] = c(frag,coef(linreg)[2], coef(linreg)[1], 
			      summary(linreg)$adj.r.squared)
      }
    }
  }

  avslope = mean(sv$slope)
  sv$avslope = avslope
  sv$yicptav = NA

  ## Repeat linear regression with average slope
  for (i in 1:nrow(transcripts)) {
    frag = transcripts[i,1]
    if (frag > 0){
      x3 = subset(x0, fragid == frag)
      if (nrow(x3) > 1){
	x3$lognpa = log(x3$npa)/log(10)
	x3$logamount = log(x3$amount)/log(10)
	yicptav = mean(x3$lognpa - avslope * x3$logamount)
	sv[which(sv$fragid == frag), ]$yicptav = yicptav
      }
    }
  }

  if(wtf){
    write.table(round(sv, digits = 8), file = paste(outputdir, "standardvalues", sep = ""), append = FALSE, 
	      quote = FALSE, sep = "\t", eol = "\n", na = "NA", dec = ".", 
	      row.names = FALSE)
  }

  output = list(standardvalues = sv, datapoints = x0, alldata = x4)

  return(output)
}

