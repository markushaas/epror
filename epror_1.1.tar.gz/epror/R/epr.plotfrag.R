## Copyright notice
## Copyright 2025 Markus Haas
##
## Statement of copying permission
## This file is part of epror.
## epror is an R package for analyzing experimental data obtained with express 
## profiling from a Beckman Coulter, Inc or Sciex CEQ8800 capillary 
## electrophoresis device.
## 
##     epror is free software: you can redistribute it and/or modify
##     it under the terms of the GNU General Public License as published by
##     the Free Software Foundation, either version 3 of the License, or
##     (at your option) any later version.
## 
##     epror is distributed in the hope that it will be useful,
##     but WITHOUT ANY WARRANTY; without even the implied warranty of
##     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##     GNU General Public License for more details.
## 
##     You should have received a copy of the GNU General Public License
##     along with epror. If not, see <http://www.gnu.org/licenses/>.

#' This function graphically displays the fragment list of an
#' AB Sciex CEQ8800 instrument fragment file
#'
#' This function displays the fragment list of an
#' AB Sciex CEQ8800 instrument fragment file. 
#' @param file The name of the AB Sciex CEQ8800 instrument file with the
#' fragment list. The file must be exported from the
#' database module of the instrument software in the txt format.
#' @param xlim Vector containing the limits of the x-axis. Defaults to c(NULL,NULL).
#' @param ylim Vector containing the limits of the y-axis. Defaults to c(NULL,NULL).
#' @param transcripts Name of the file wiht a table of all fragments 
#' which should be detected. This file will be read by the function 
#' epr.readtranscripts(). Defaults to "transcripts.txt".
#' @importFrom graphics par plot title grid lines points legend rect segments text
#' @export

epr.plotfrag = function(file, transcripts = "transcripts.txt", 
			 xlim = c(NULL,NULL), ylim = c(NULL,NULL)){

  colors = c("red", "blue", rgb(255, 192, 203, maxColorValue = 255), 
	     rgb(215, 215, 215, maxColorValue = 255))
  legend = c("size standard", "fragments", "expected range reference", 
	     "expected range fragments")
  std = NULL
  dye = NULL
  transcriptid = NULL

  ## Read ceq fragment file
  x = epr.readfragfile(file)

  ## Read list of fragments to search for
  if(file.exists(transcripts)){
    t = epr.readtranscripts(transcripts)
  }

  ## Read analysisparameter
  if(file.exists("epr.settings")){
    settings = epr.readsettings()
  } else {
    settings = list('range' = 0, 'universalprimerdye' = 'D4')
  }

  par(mar = c(3.5,5.5,2,0.5))

  if(nrow(x) > 0){
    ## Select peaks from sizestand and pcr, resp.
    sizestd = subset(x, std == " * ")
    pcr = subset(x, dye == settings[["universalprimerdye"]])
    ymax = max(max(sizestd$area), ifelse(nrow(pcr) > 0, max(pcr$area), 1))

    plot(x$size,x$area,type = "n", 
	 xlim = c(ifelse(!is.null(xlim[1]), xlim[1], 50), ifelse(!is.null(xlim[2]), xlim[2], 450)),
	 ylim = c(ifelse(!is.null(ylim[1]), ylim[1], 0), ifelse(!is.null(ylim[2]), ylim[2], ymax)),
	 las = 1, xlab = "", ylab = "")

    title(ylab =  "Peak Area", mgp=c(4,1,0))
    title(xlab =  "Size in Nucleotides", mgp=c(2,1,0))
    title(main =  paste(file))

    grid(nx = NULL, ny = NULL, col = "lightgray", lty = "dotted", lwd = 1.5)

    if(file.exists(transcripts)){
      rect(subset(t, transcriptid == 0)$runlength - settings[["range"]], 0, 
	   subset(t, transcriptid == 0)$runlength + settings[["range"]], 200000, 
	   col = colors[3], border = NA)
      rect(subset(t, transcriptid != 0)$runlength - settings[["range"]], 0, 
	   subset(t, transcriptid != 0)$runlength + settings[["range"]], 200000, 
	   col = colors[4], border = NA)
    }

    segments(x0 = sizestd$stdsize, y0 = sizestd$area, y1 = 0, col = colors[1], lwd = 2)
    if(nrow(pcr) > 1){
      segments(x0 = pcr$size, y0 = pcr$area, y1 = 0, col = colors[2], lwd = 2)
    }

    legend("topright", legend = legend, bg = "white", col = colors, lty=1, lwd = 3)
  }else{
    plot(1, type = "n", axes = F, xlab = "", ylab = "")
    title(main =  paste(file))
    box()
    text(1,1,"No data points")
  }
}

