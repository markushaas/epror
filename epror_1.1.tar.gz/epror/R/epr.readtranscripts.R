## Copyright notice
## Copyright 2025 Markus Haas
##
## Statement of copying permission
## This file is part of epror.
## epror is an R package for analyzing experimental data obtained with express 
## profiling from a Beckman Coulter, Inc or Sciex CEQ8800 capillary 
## electrophoresis device.
## 
##     epror is free software: you can redistribute it and/or modify
##     it under the terms of the GNU General Public License as published by
##     the Free Software Foundation, either version 3 of the License, or
##     (at your option) any later version.
## 
##     epror is distributed in the hope that it will be useful,
##     but WITHOUT ANY WARRANTY; without even the implied warranty of
##     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##     GNU General Public License for more details.
## 
##     You should have received a copy of the GNU General Public License
##     along with epror. If not, see <http://www.gnu.org/licenses/>.

#' This function reads a table with all transcripts that should be detected
#' with the epror package.
#'
#' This function reads a table with all transcripts that should be detected
#' with the package. The file must have two <TAB> separated columns. In the first
#' column the file should have a numerical id. The id 0 is reserved for the 
#' transcript which serves as internal reference for the rt-pcr. The values
#' in the second column have also to be numerical and stand for the run length
#' of the transcripts. The function returns a data frame with the transcriptid in the 
#' first column and the runlength in the second column.
#' @param file File name with your table of transcripts. Defaults to "transcripts.txt".
#' @import utils
#' @export
#' @examples 
#' file <- system.file("extdata", "transcripts.txt", package="epror")
#' epr.readtranscripts(file)

epr.readtranscripts = function(file = "transcripts.txt") {
  lines = readLines(file)
  hitrows = grep("^[0-9]+\t", lines)

  if(length(hitrows)){
    x = read.table(textConnection(lines[seq(from = min(hitrows), 
					    to = max(hitrows))]),
		    sep = "\t", colClasses = c("numeric","numeric"))
    colnames(x) = c("transcriptid","runlength")

    return(x)
  }
}

