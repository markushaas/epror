## Copyright notice
## Copyright 2025 Markus Haas
##
## Statement of copying permission
## This file is part of epror.
## epror is an R package for analyzing experimental data obtained with express 
## profiling from a Beckman Coulter, Inc or Sciex CEQ8800 capillary 
## electrophoresis device.
## 
##     epror is free software: you can redistribute it and/or modify
##     it under the terms of the GNU General Public License as published by
##     the Free Software Foundation, either version 3 of the License, or
##     (at your option) any later version.
## 
##     epror is distributed in the hope that it will be useful,
##     but WITHOUT ANY WARRANTY; without even the implied warranty of
##     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##     GNU General Public License for more details.
## 
##     You should have received a copy of the GNU General Public License
##     along with epror. If not, see <http://www.gnu.org/licenses/>.

#' This function plots an electropherograms of
#' all AB Sciex CEQ8800 instrument files in the current directory
#'
#' This function plots electropherograms from
#' AB Sciex CEQ8800 instrument files.
#' All files which match the pattern given of the parameter rawfileext in the 
#' current working directory  will be parsed. This function is a wrapper
#' for the function epr.plotraw() and allows you to
#' cycles through all files in the working directory which match the
#' file extension pattern given with the parameter rawfileext.
#' @param rawfileext The extension of the files which should be read by
#' the function. Defaults to "ceqraw".
#' @param xlim Vector containing the limits of the x-axis. Defaults to c(NULL,NULL).
#' @param ylim Vector containing the limits of the y-axis. Defaults to c(NULL,NULL).
#' @export

epr.plotallraw = function(rawfileext = "ceqraw", xlim = c(NULL,NULL), ylim = c(NULL,NULL)){

  filelist = Sys.glob(paste("*.", rawfileext, sep = ""))
  for (file in filelist){
    epr.plotraw(file, xlim = xlim, ylim = ylim)
    invisible(readline(prompt="Press [enter] to continue"))
  }
  dev.off()
}

