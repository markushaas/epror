## Copyright notice
## Copyright 2025 Markus Haas
##
## Statement of copying permission
## This file is part of epror.
## epror is an R package for analyzing experimental data obtained with express 
## profiling from a Beckman Coulter, Inc or Sciex CEQ8800 capillary 
## electrophoresis device.
## 
##     epror is free software: you can redistribute it and/or modify
##     it under the terms of the GNU General Public License as published by
##     the Free Software Foundation, either version 3 of the License, or
##     (at your option) any later version.
## 
##     epror is distributed in the hope that it will be useful,
##     but WITHOUT ANY WARRANTY; without even the implied warranty of
##     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##     GNU General Public License for more details.
## 
##     You should have received a copy of the GNU General Public License
##     along with epror. If not, see <http://www.gnu.org/licenses/>.

#' This function reads a file with the fragment data of an AB Sciex CEQ800 instrument
#'
#' This function reads a table with fragment data of an 
#' AB Sciex CEQ800 instrument. The file must be exported in the csv format
#' from the database module of the CEQ800 software. This function returns a
#' data frame with the fragment data.
#' @param file File name with fragment data from an AB Sciex CEQ800 instrument.
#' @import utils
#' @export
#' @examples 
#' file <- system.file("extdata", "FA034580.ceqfrag", package="epror")
#' epr.readfragfile(file)

epr.readfragfile = function(file) {
  lines = readLines(file)

  if(length(lines) > 2){
    x = read.table(textConnection(lines[seq(from = 3, to = length(lines))]), 
		   colClasses = c("character", "integer", "character", 
				  rep("numeric", 9), rep("NULL", 5)), sep = "\t")

  } else {
    x = data.frame(matrix(vector(),ncol=12))
  }

  names(x) = c("std","peak","dye","migtime","stdsize","size", "height", "area", 
	       "width", "mob", "eff", "res")
  
  return(x)

}

