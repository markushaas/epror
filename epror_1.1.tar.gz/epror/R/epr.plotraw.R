## Copyright notice
## Copyright 2025 Markus Haas
##
## Statement of copying permission
## This file is part of epror.
## epror is an R package for analyzing experimental data obtained with express 
## profiling from a Beckman Coulter, Inc or Sciex CEQ8800 capillary 
## electrophoresis device.
## 
##     epror is free software: you can redistribute it and/or modify
##     it under the terms of the GNU General Public License as published by
##     the Free Software Foundation, either version 3 of the License, or
##     (at your option) any later version.
## 
##     epror is distributed in the hope that it will be useful,
##     but WITHOUT ANY WARRANTY; without even the implied warranty of
##     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##     GNU General Public License for more details.
## 
##     You should have received a copy of the GNU General Public License
##     along with epror. If not, see <http://www.gnu.org/licenses/>.

#' This function plots an electropherograms from an 
#' AB Sciex CEQ8800 instrument
#'
#' This function plots an electropherogram from an
#' AB Sciex CEQ8800 instrument files.
#' @param file The name of the AB Sciex CEQ8800 instrument file with the
#' raw data of the electropheorgramm. The file must be exported from the
#' database module of the instrument software in the txt format.
#' @param xlim Vector containing the limits of the x-axis. Defaults to c(NULL,NULL).
#' @param ylim Vector containing the limits of the y-axis. Defaults to c(NULL,NULL).
#' @importFrom graphics par plot title grid lines points legend
#' @export

epr.plotraw = function(file, xlim = c(NULL,NULL), ylim = c(NULL,NULL)){

  channels = c("D1","D2","D3","D4")
  col = c("green", "red", "cyan", "blue","magenta")

  x = epr.readrawdata(file)
  cap = x[1,]$cap

  par(mar = c(3.5,5.5,2,0.5))

  maxrfu = max(max(x$D1), max(x$D2), max(x$D3), max(x$D4))

  plot(1,type = "n", 
       las = 1, 
       xlab = "", 
       ylab = "", 
       xlim = c(ifelse(!is.null(xlim[1]), xlim[1], 0), ifelse(!is.null(xlim[2]), xlim[2], max(x$time))),
       ylim = c(ifelse(!is.null(ylim[1]), ylim[1], 0), ifelse(!is.null(ylim[2]), ylim[2], maxrfu)))

  title(ylab =  "Relative Fluorescence", mgp=c(4,1,0))
  title(xlab =  "Migration Time in min", mgp=c(2,1,0))
  title(main =  paste(file, cap, sep = ", Cap: "))

  grid(nx = NULL, ny = NULL, col = "lightgray", lty = "dotted", lwd = 1.5)

  for (i in 1:length(channels)){
    channel = channels[i]
    xi = x[c("time",channel)]
    lines(xi[,1], xi[,2], col = col[i], lwd = 1)
    xs = subset(xi, xi[,2] == 131070)
    if (nrow(xs) > 0) {points(xs[,1], xs[,2], col = "magenta", pch = 20)}
  }

  legend("topright", legend = c(channels, "SAT"), bg = "white", col = col, 
	 lty = c(rep(1,4),NA), pch = c(rep(NA,4), 1), lwd = 2)
}

